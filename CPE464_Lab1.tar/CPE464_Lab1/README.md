CPE464 Program 1: Trace
Written By: Samuel Mushinsky

Certain parts of this code which were assited by AI have been highlighted such as parts of the makefile, some very basic general functions, and a flag in main that i have no idea how or why it works but it does. 

Most comments exist within the trace.c file explaining what, how, why, etc. 