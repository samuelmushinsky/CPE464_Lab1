/* Checksum declaration 
 * shadows@whitefang.com
 */

unsigned short in_cksum(unsigned short *addr,int len);



